# Day 20 - Basic Data Visualization
# Using Pandas and Matplotlib with a movie dataset

import pandas as pd
import matplotlib.pyplot as plt


# Step 1: Read the movie dataset
movies = pd.read_csv("movies.csv")

print("Movie Dataset")
print(movies)


# Step 2: Check the basic information
print("\nDataset Information:")
print(movies.info())


# Step 3: Movie Ratings - Line Plot
plt.figure(figsize=(10, 5))
plt.plot(movies["Title"], movies["Rating"], marker="o")
plt.title("Movie Ratings")
plt.xlabel("Movie")
plt.ylabel("Rating")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# Step 4: Number of Movies by Genre - Bar Chart
genre_counts = movies["Genre"].value_counts()

plt.figure(figsize=(8, 5))
plt.bar(genre_counts.index, genre_counts.values)
plt.title("Number of Movies by Genre")
plt.xlabel("Genre")
plt.ylabel("Number of Movies")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# Step 5: Distribution of Ratings - Histogram
plt.figure(figsize=(8, 5))
plt.hist(movies["Rating"], bins=5)
plt.title("Distribution of Movie Ratings")
plt.xlabel("Rating")
plt.ylabel("Number of Movies")
plt.show()


# Step 6: Movie ID vs Rating - Scatter Plot
plt.figure(figsize=(8, 5))
plt.scatter(movies["Movie_ID"], movies["Rating"])
plt.title("Movie ID vs Rating")
plt.xlabel("Movie ID")
plt.ylabel("Rating")
plt.show()


# Step 7: Average Rating by Genre
genre_rating = movies.groupby("Genre")["Rating"].mean().sort_values(ascending=False)

plt.figure(figsize=(8, 5))
bars = plt.bar(genre_rating.index, genre_rating.values)

for bar, value in zip(bars, genre_rating.values):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        value,
        f"{value:.1f}",
        ha="center",
        va="bottom"
    )

plt.title("Average Rating by Genre")
plt.xlabel("Genre")
plt.ylabel("Average Rating")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# Step 8: Print the average rating of each genre
print("\nAverage Rating by Genre:")
print(genre_rating)


# Conclusion
print("\nVisualization practice completed!")
